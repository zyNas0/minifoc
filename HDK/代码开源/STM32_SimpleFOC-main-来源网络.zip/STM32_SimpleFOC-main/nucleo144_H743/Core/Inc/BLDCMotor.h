/*
 * BLDCMotor.h
 *
 *  Created on: 17 Mar 2021
 *      Author: natal
 */

#ifndef INC_BLDCMOTOR_H_
#define INC_BLDCMOTOR_H_

#include "../src/common/base_classes/FOCMotor.h"
#include "../src/common/base_classes/Sensor.h"
#include "../src/common/base_classes/BLDCDriver.h"
#include "../src/common/foc_utils.h"
#include "../src/common/time_utils.h"
#include "../src/common/defaults.h"

/**
 BLDC motor class
*/
class BLDCMotor: public FOCMotor
{
  public:
    /**
     BLDCMotor class constructor
     @param pp pole pairs number
     */
    BLDCMotor(int pp);

    /**
     * Function linking a motor and a foc driver
     *
     * @param driver BLDCDriver class implementing all the hardware specific functions necessary PWM setting
     */
    void linkDriver(BLDCDriver* driver);

    /**
      * BLDCDriver link:
      * - 3PWM
      * - 6PWM
    */
    BLDCDriver* driver;

    /**  Motor hardware init function */
  	void init() override;
    /** Motor disable function */
  	void disable() override;
    /** Motor enable function */
    void enable() override;

    /**
     * Function initializing FOC algorithm
     * and aligning sensor's and motors' zero position
     */
    int initFOC( float zero_electric_offset = NOT_SET , Direction sensor_direction = Direction::CW) override;
    /**
     * Function running FOC algorithm in real-time
     * it calculates the gets motor angle and sets the appropriate voltages
     * to the phase pwm signals
     * - the faster you can run it the better Arduino UNO ~1ms, Bluepill ~ 100us
     */
    void loopFOC() override;

    /**
     * Function executing the control loops set by the controller parameter of the BLDCMotor.
     *
     * @param target  Either voltage, angle or velocity based on the motor.controller
     *                If it is not set the motor will use the target set in its variable motor.target
     *
     * This function doesn't need to be run upon each loop execution - depends of the use case
     */
    void move(float target = NOT_SET) override;

    float Ua,Ub,Uc;//!< Current phase voltages Ua,Ub and Uc set to motor
    float Ualpha,Ubeta; //!< Phase voltages U alpha and U beta used for inverse Park and Clarke transform


  private:
    // FOC methods
    /**
    * Method using FOC to set Uq to the motor at the optimal angle
    * Heart of the FOC algorithm
    *
    * @param Uq Current voltage in q axis to set to the motor
    * @param Ud Current voltage in d axis to set to the motor
    * @param angle_el current electrical angle of the motor
    */
    void setPhaseVoltage(float Uq, float Ud, float angle_el);
    /** Sensor alignment to electrical 0 angle of the motor */
    int alignSensor();
    /** Motor and sensor alignment to the sensors absolute 0 angle  */
    int absoluteZeroAlign();


    // Open loop motion control
    /**
     * Function (iterative) generating open loop movement for target velocity
     * it uses voltage_limit variable
     *
     * @param target_velocity - rad/s
     */
    void velocityOpenloop(float target_velocity);
    /**
     * Function (iterative) generating open loop movement towards the target angle
     * it uses voltage_limit and velocity_limit variables
     *
     * @param target_angle - rad
     */
    void angleOpenloop(float target_angle);
    // open loop variables
    long open_loop_timestamp;
};

#endif /* INC_BLDCMOTOR_H_ */
